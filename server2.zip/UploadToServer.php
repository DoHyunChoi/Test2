<?php

	$count	=$_POST['CNT'];
  
    
     




 for ($i=1 ; $i <= $count ; $i++) { 
	$file_name = "";
	$file_path = "uploads/";
	$file_name = "uploaded_file" . $i;

    $file_path = $file_path . basename( $_FILES[$file_name]['name']);
    if(move_uploaded_file($_FILES[$file_name]['tmp_name'], $file_path)) {
        echo "success";
    } else{
        echo "fail";
    }

 }



 ?>