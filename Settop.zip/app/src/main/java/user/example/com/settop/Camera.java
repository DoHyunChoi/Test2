package user.example.com.settop;

import android.util.Log;

/**
 * Created by 영두 on 2016-11-22.
 */
public class Camera {
    Camera() {
    }

    public void hello() {
        Log.d("Test", "Hello");
    }
}
